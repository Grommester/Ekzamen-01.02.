﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryStudNumber
{
    public class ClassChecker
    {
        public static string result = "";

        public static bool UpSymb(char a)
        {
            if ((a >= 'A' && a <= 'Z') || (a >= 'А' && a <= 'Я'))
            {
                return true;
            }

            return false;
        }

        public static bool validateStudNumber(int year, int group, string fio)
        {
            // Year_Check
            if (year < 2018 || year > 2030)
            {
                return false;
            }

            // Group_Check
            if (group < 180 || group > 309)
            {
                return false;
            }

            // Fio_Check
            if (fio.Length < 5)
            {
                return false;
            }

            if (fio.Any(char.IsDigit))
            {
                return false;
            }

            if (!fio.Any(char.IsUpper) || !UpSymb(fio[0]))
            {
                return false;
            }

            if (fio.Intersect("'!@#№$%^:&?*()./}]{[<>,+=_").Count() != 0)
            {
                return false;
            }

            result = year.ToString() + '.' + group.ToString() + '.' + fio[0] + fio[1] + fio[2];

            return true;
        }
        static void Main(string[] args)
        {
            int year = 2020;
            int group = 189;
            string fio = "Дьяков Артём Сергеевич";
            bool actual = ClassChecker.validateStudNumber(year, group, fio);
            Console.WriteLine("res " + actual);
        }
    }
}