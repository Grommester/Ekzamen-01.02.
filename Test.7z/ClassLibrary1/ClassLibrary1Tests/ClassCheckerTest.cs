﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClassLibraryStudNumber;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryStudNumber.Tests
{
    [TestClass()]
    public class StudNumberCheckerTests
    {
        [TestMethod()]
        public void Check_SmallYear_RerurnsFalse()
        {
            int year = 5;
            int group = 189;
            string fio = "Дьяков Артём Сергеевич";
            bool actual = ClassChecker.validateStudNumber(year, group, fio);
            Assert.IsFalse(actual);
        }

        [TestMethod()]
        public void Check_BigYear_RerurnsFalse()
        {
            int year = 20000;
            int group = 189;
            string fio = "Дьяков Артём Сергеевич";
            bool actual = ClassChecker.validateStudNumber(year, group, fio);
            Assert.IsFalse(actual);
        }

        [TestMethod()]
        public void Check_Year_RerurnsTrue()
        {
            int year = 2020;
            int group = 189;
            string fio = "Дьяков Артём Сергеевич";
            bool expected = true;
            bool actual = ClassChecker.validateStudNumber(year, group, fio);
            Assert.AreEqual(expected, actual);
        }

        //

        [TestMethod()]
        public void Check_SmallGroup_RerurnsFalse()
        {
            int year = 2020;
            int group = 1;
            string fio = "Дьяков Артём Сергеевич";
            bool actual = ClassChecker.validateStudNumber(year, group, fio);
            Assert.IsFalse(actual);
        }

        [TestMethod()]
        public void Check_BigGroup_RerurnsFalse()
        {
            int year = 2020;
            int group = 100000;
            string fio = "Дьяков Артём Сергеевич";
            bool actual = ClassChecker.validateStudNumber(year, group, fio);
            Assert.IsFalse(actual);
        }

        [TestMethod()]
        public void Check_Group_RerurnsTrue()
        {
            int year = 2020;
            int group = 189;
            string fio = "Дьяков Артём Сергеевич";
            bool expected = true;
            bool actual = ClassChecker.validateStudNumber(year, group, fio);
            Assert.AreEqual(expected, actual);
        }

        //

        [TestMethod()]
        public void Check_SmallFio_RerurnsFalse()
        {
            int year = 2020;
            int group = 189;
            string fio = "ДАС";
            bool actual = ClassChecker.validateStudNumber(year, group, fio);
            Assert.IsFalse(actual);
        }

        [TestMethod()]
        public void Check_FioDigits_RerurnsFalse()
        {
            int year = 2020;
            int group = 189;
            string fio = "Дья4ков Артём Сергеевич";
            bool actual = ClassChecker.validateStudNumber(year, group, fio);
            Assert.IsFalse(actual);
        }

        [TestMethod()]
        public void Check_FioNoUppers_RerurnsFalse()
        {
            int year = 2020;
            int group = 189;
            string fio = "дьяков артём сергеевич";
            bool actual = ClassChecker.validateStudNumber(year, group, fio);
            Assert.IsFalse(actual);
        }

        [TestMethod()]
        public void Check_Fio1stNotUpper_RerurnsFalse()
        {
            int year = 2020;
            int group = 189;
            string fio = "дьяков Артём Сергеевич";
            bool actual = ClassChecker.validateStudNumber(year, group, fio);
            Assert.IsFalse(actual);
        }

        [TestMethod()]
        public void Check_FioSpaceSymbols_RerurnsFalse()
        {
            int year = 2020;
            int group = 189;
            string fio = "Дьяков>Артём<Сергеевич";
            bool actual = ClassChecker.validateStudNumber(year, group, fio);
            Assert.IsFalse(actual);
        }
    }
}